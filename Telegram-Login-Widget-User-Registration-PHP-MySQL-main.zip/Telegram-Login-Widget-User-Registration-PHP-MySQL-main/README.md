# Telegram Login Widget User Registration PHP MySQL

_Creating User Registration System Sign Up And Login Using Telegram Login Widget - PHP MySQL HTML CSS_

![YouTube Thumbnail](https://raw.githubusercontent.com/saeedkohansal/Telegram-Login-Widget-User-Registration-PHP-MySQL/main/image/Telegram-Login-Widget-User-Registration-PHP-MySQL.png "YouTube Thumbnail")
![Files Explained](https://raw.githubusercontent.com/saeedkohansal/Telegram-Login-Widget-User-Registration-PHP-MySQL/main/image/Files-Explained.png "Files Explained")

Hello programmers, Welcome to gilgeekify! My name is Saeed Kohansal, and I hope you have a great time. In this video, I'm gonna show you how to create a complete User Registration System using Telegram Login Widget from scratch. I will use PHP and MySQL for the Backend and Database, also HTML and CSS for the Web-Based User Interface. You can use this widget to Sign Up and Log In users to your website. The Telegram login widget is a simple way to authorize users on your website. We can use Telegram Login Widget for external websites. When you use Telegram login for the first time, their widget asks for your phone number and sends you a confirmation message via the Telegram Application to authorize your browser. Once this is done, you get a two-click login on every website that supports signing in with Telegram. Logging in will send your Telegram name, username, and your profile picture to the website owner. Your phone number remains hidden. The Telegram Login Widget does not give you the user's phone number. The website can also request permission to send you messages from their bot. Also, I will show you how to create a Telegram Bot from scratch.

## Video Tutorial [ Creating This Widget From Scratch ]
[https://youtu.be/62o5rk4439U](https://youtu.be/62o5rk4439U)

 

## If You Enjoy My Content, Please Support Me 😍🙏

💙 PAYPAL DONATION

https://paypal.me/gilgeekify

❤️ PATREON

https://www.patreon.com/gilgeekify

💛 BUY ME A COFFEE

https://www.buymeacoffee.com/gilgeekify

🪙 My Public Address To Receive BTC • Bitcoin

bc1qerc5ev074cqknu9nz589w4vjf5ecmhuc2df83h

🥈 My Public Address To Receive ETH • Ethereum

0x566A47B9731209A5144336D274D44224bfb9C0ea
